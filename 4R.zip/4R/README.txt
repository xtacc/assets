=== JOIN OUR DISCORD FOR SUPPORT AND UPDATES ===

Our discord server link is discord.gg/dat

FAQ:
Q: How does this work?
A: When you run V4.exe, the file will extract itself and load all of the vape files.
Q: Why is this obfuscated/why does it extract? When I deobfuscate, why is the bat full of random unicodes?
A: Everything is obfuscated and requires being extracted to prevent being patched or leaked and also to prevent skidding.
Q: Is this safe?
A: Yes, our crack is safe.
Q: BUT VIRUSTOTAL SAYS ITS A VIRUS!!!!!!!!!
A: VirusTotal only lists us as "RiskWare" because there is a level of risk in obfuscated code obviously because it cannot read it. Other detections such as "malware gen" are not true as it is saying its malware, however it is simply an obfuscated bat2exe file extracting obfuscated Java files. It is up to you whether you trust us or not.

Important info:
- We only support the Vanilla client and Lunar Client. More to come soon.
- Vape is fully external which means it is extremely hard to be caught as long as you are not blatant.
- We do not plan to make any profit off of this.
- If the rightful owners would like this removed, we will happily comply.
- You must have Java 17+ to run this. You can download the latest java at Java.com. The built in Java with minecraft or java 8 will not work as we use newer features.

How to use:
- Load into Lunar or Vanilla Minecraft. Vape only officially supports up to 1.16. You can try to run it on higher versions but we cannot guarantee full support.
- Join a singleplayer or multiplayer game. You cannot inject properly on the main menu and it may not work otherwise.
- Once you are in, run V4.exe. It will extract the Vape project and run the injection script. Within ~40 seconds, you should see a text in the command prompt saying "ready in -- ms".
- If you do, have fun! Remember the CMD needs to stay opened the entire time you are playing.
If you don't, read below.

Common fixes:
- Error: "Could not create the Java Virtual Machine"
- Fix: Your Java is outdated for Vape. Download the newest version of Java from above and restart your CMD prompt.
- Error: "client crashed at stage -"
- Fix: There is a 50-50 percent chance of this happening. It typically only happens when you use Lunar Client. If this happens to you, use the Vanilla launcher on a different version like 1.12, or if you were already using it use Lunar Client on a different version.

Any other problems or anything you need to ask us? Feel free to join our discord above :')